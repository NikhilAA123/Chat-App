# Chat_app
A Chat app where user can send messages in a room or send private message to a user
